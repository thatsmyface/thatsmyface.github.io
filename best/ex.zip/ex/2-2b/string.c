#include <stdio.h>
int main()
{
    // string formatting
    // to store a string C uses a char array
    char a[] = "Hello World!";
    printf("%s\n", a);
    return 0;
}
