#include <stdio.h>

int main()
{
    /*
     1. A minus(-) sign after % specifies a left alignment
     2. A number after % specifies the minimum field width to be printed
     If the characters are less than the size of width the remaining space is filled with space and if it is greater than it printed as it is without truncation.
     3. A period( . ) symbol seperate field width with the precision.
     Precision tells the maximum number of digits in integer, charcters in string and number of digits after decimal part in floating value.
     */
    
    char str[] = "COS 135 at UMaine";
    float number = 12.0123456789;
    printf("%50s\n", str);
    printf("%-50s\n", str);
    printf("%20.10s\n", str);
    printf("%-20.7s\n", str);
    
    printf("%10.3f\n", number);
    return 0;
}
