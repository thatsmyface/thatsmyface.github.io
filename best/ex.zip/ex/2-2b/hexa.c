#include <stdio.h>
int main()
{
    // Unsigned Hexadecimal for integer : %x, %X
    int a = 15;
    printf("%x\n", a);
    return 0;
}
