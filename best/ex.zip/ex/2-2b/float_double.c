#include <stdio.h>
int main()
{
    //Double format specifier : %f, %e or %E
    float a = 12.67;
    printf("%f\n", a);
    printf("%e\n", a);
    return 0;
}
