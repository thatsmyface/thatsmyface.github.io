#include <stdio.h>
int main()
{
    // Unsigned Octal number for integer : %o
    // convert 67 into octal
    int a = 67;
    printf("%o\n", a);
    return 0;
}
