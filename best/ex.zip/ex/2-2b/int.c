#include <stdio.h>
int main()
{
    // Integer format specifier : %d, %i
    int x = 45, y = 90;
    printf("%d\n", x);
    printf("%i\n", x);
    printf("%d\n", y);
    printf("%i\n", y);
    return 0;
}
