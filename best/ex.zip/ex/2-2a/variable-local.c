#include <stdio.h>

int main()
{
    // Variable declaration
    float radius;
    float area;
    
    // Step 1: set radius (initialization)
    radius =20;
    
    // Step 2: Compute area
    area = radius * radius * 3.14159;
    
    // Step 3: Display the result
    printf("The area is %f \n", area);
    
    return 0;
}
